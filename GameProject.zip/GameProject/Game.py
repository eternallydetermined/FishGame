import sys
import pygame
from pygame import key
from pygame.sprite import Sprite, Group, spritecollideany
from pygame.time import Clock

from data import settings


class Player(Sprite):
    def __init__(self, *groups):
        super().__init__(*groups)
        self.health = 3
        self.image = pygame.image.load("data/Friend.png").convert_alpha()
        self.world_rect = self.image.get_rect().move(10, 300)
        self.rect = self.world_rect
        self.world_inset_rect = None
        self.update_inset()

    def update_inset(self):
        self.world_inset_rect = self.world_rect.inflate(50, 50)

    def update(self, keys):
        if keys[pygame.K_LEFT]:
            self.move_left()
        if keys[pygame.K_RIGHT]:
            self.move_right()
        if keys[pygame.K_DOWN]:
            self.move_down()
        if keys[pygame.K_UP]:
            self.move_up()
        if keys[pygame.K_SPACE]:
            pass
        if self.world_rect.right > settings.WORLD_WIDTH - 500:
            self.world_rect.right = settings.WORLD_WIDTH - 500
        if self.world_rect.left < 0:
            self.world_rect.left = 0
        if self.world_rect.top < 0:
            self.world_rect.top = 0
        if self.world_rect.bottom > settings.WINDOW_HEIGHT:
            self.world_rect.bottom = settings.WINDOW_HEIGHT
        self.update_inset()

    def move_left(self):
        self.world_rect.left -= 5

    def move_right(self):
        self.world_rect.left += 10

    def move_up(self):
        self.world_rect.bottom -= 10

    def move_down(self):
        self.world_rect.top += 10

    def shoot(self):
        pass


class Ground(Sprite):
    def __init__(self, *args):
        super().__init__(*args)
        self.image = pygame.image.load("data/Seabed.png").convert()
        self.world_rect = self.image.get_rect().copy()
        self.world_rect.bottom = settings.WINDOW_HEIGHT
        assert self.world_rect.width == settings.WORLD_WIDTH


class Viewport:
    def __init__(self):
        self.left = 0

    def update(self, focus):
        if focus.world_rect.left < 300:
            self.left = 0
        elif focus.world_rect.right > settings.WORLD_WIDTH - settings.WINDOW_WIDTH + 400:
            self.left = settings.WORLD_WIDTH - settings.WINDOW_WIDTH
        else:
            self.left = focus.world_rect.left - 300

    def update_rect(self, group):
        for sprite in group:
            sprite.rect = sprite.world_rect.move(-self.left, 0)


class YourBullet(Sprite):
    def __init__(self, owner, *groups):
        super().__init__(*groups)
        self.spawn = owner.world_rect.right
        self.image = pygame.image.load("data/Bubble.png")
        self.owner = owner
        self.world_rect = self.image.get_rect().move(owner.world_rect.right, ((owner.world_rect.top + owner.world_rect.bottom)/2) - 15)

    def update(self):
        if self.world_rect.left - self.spawn < 600:
            self.world_rect.left += 20
        else:
            self.kill()


class Enemy(Sprite):
    def __init__(self, x, y, *groups):
        super().__init__(*groups)
        self.health = 1
        self.image = pygame.image.load("data/Foe.png").convert_alpha()
        self.world_rect = self.image.get_rect().move(x, y)

    def update(self):
        self.world_rect.left -= 4

class Boss(Sprite):
    def __init__(self, x, y, *groups):
        super().__init__(*groups)
        self.health = 15
        self.image = pygame.image.load("data/BossCrab.png").convert_alpha()
        self.world_rect = self.image.get_rect().move(x, y)
        self.rect = self.world_rect

class Water(Sprite):
    def __init__(self, *groups):
        super().__init__(*groups)
        self.image = pygame.image.load("data/Background.png").convert()
        self.world_rect = self.image.get_rect().move(0, 0)


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.init()
        self.finished = False
        self.active = True
        self.screen = pygame.display.set_mode((settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT))
        pygame.display.set_caption("Fish Game")
        self.player = Player()
        self.player_group = Group()
        self.player_group.add(self.player)
        self.enemies = Group()
        dummy = Enemy(200, 400)
        more = Enemy(1000, 300)
        mmore = Enemy(700, 500)
        mmmore = Enemy(300, 200)
        mmmmmore = Enemy(1200, 550)
        mmmmore = Enemy(1500, 400)
        some = Enemy(2200, 170)
        somemore = Enemy(2300, 200)
        evenmore = Enemy(2400, 225)
        a = Enemy(2600, 440)
        b = Enemy(2700, 500)
        c = Enemy(2800, 530)
        self.enemies.add(a)
        self.enemies.add(b)
        self.enemies.add(c)
        self.enemies.add(somemore)
        self.enemies.add(evenmore)
        self.enemies.add(some)
        self.enemies.add(more)
        self.enemies.add(mmore)
        self.enemies.add(mmmore)
        self.enemies.add(mmmmore)
        self.enemies.add(mmmmmore)
        boss = Boss(settings.WORLD_WIDTH - 500, 200)
        self.boss = boss
        self.boss_group = Group()
        self.boss_group.add(self.boss)
        self.enemies.add(dummy)
        self.enemies.add(boss)
        self.my_font = pygame.font.Font("data/arial.ttf", 30)
        self.friendly_fire = Group()
        test = YourBullet(self.player)
        self.friendly_fire.add(test)
        self.aggravating_fire = Group()
        self.background = Group()
        self.background.add(Water())
        self.background.add(Ground())
        self.camera = Viewport()
        self.camera.update(self.player)


    def check_boundary_collision(self):
        ground = Ground()
        if ground.world_rect.top < self.player.world_rect.bottom:
            self.player.world_rect.bottom = ground.world_rect.top



    def check_player_collisions(self, friend=Player, foe=Enemy):
        return friend.world_rect.colliderect(foe.world_rect)


    def check_enemy_collision(self):
        if self.player.alive() and \
                (collided_with := spritecollideany(self.player, self.enemies, self.check_player_collisions)) is not None:
            self.player.health += 1
            collided_with.health -= 1
            if collided_with.health == 0:
                collided_with.kill()
            if self.player.health == 0:
                self.player.kill()

    def check_boss_collision(self):
        if self.player.alive() and\
                (collided_with := spritecollideany(self.boss, self.friendly_fire, self.check_if_boss_hit)) is not None:
            self.boss.health -= 1
            collided_with.kill()
            if self.boss.health == 0:
                self.boss.kill()
                self.player.health += 9000
                self.finished = True

    def check_if_boss_hit(self, boss, bullet):
        return boss.world_rect.colliderect(bullet.world_rect)


    def sequence(self):
        timer = Clock()
        while self.active:
            while not self.finished:
                self.handle_events()
                self.update()
                self.draw()
                pygame.display.flip()
                timer.tick(30)
            while self.finished and self.active:
                self.finish_handle_events()
                self.update_end()
                timer.tick(30)

    def finish_handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit(0)
                if event.key == pygame.K_r:
                    self.player.kill()
                    self.player = Player()
                    self.player_group.add(self.player)
                    dummy = Enemy(200, 400)
                    more = Enemy(1000, 300)
                    mmore = Enemy(700, 500)
                    mmmore = Enemy(300, 200)
                    mmmmmore = Enemy(1200, 550)
                    mmmmore = Enemy(1500, 400)
                    mmmmmmore = Enemy(2000, 100)
                    mmmmmmmore = Enemy(2500, 300)
                    mmmmmmmmore = Enemy(2250, 450)
                    mmmmmmmmmore = Enemy(3500, 225)
                    mmmmmmmmmmore = Enemy(3000, 115)
                    some = Enemy(2200, 170)
                    somemore = Enemy(2300, 200)
                    evenmore = Enemy(2400, 225)
                    a = Enemy(2600, 440)
                    b = Enemy(2700, 500)
                    c = Enemy(2800, 530)
                    self.enemies.add(a)
                    self.enemies.add(b)
                    self.enemies.add(c)
                    self.enemies.add(somemore)
                    self.enemies.add(evenmore)
                    self.enemies.add(some)
                    self.enemies.add(more)
                    self.enemies.add(more)
                    self.enemies.add(mmore)
                    self.enemies.add(mmmore)
                    self.enemies.add(mmmmore)
                    self.enemies.add(mmmmmore)
                    self.enemies.add(mmmmmmmmmmore)
                    self.enemies.add(mmmmmmmmmmore)
                    self.enemies.add(mmmmmmore)
                    self.enemies.add(mmmmmmmore)
                    self.enemies.add(mmmmmmmmore)
                    self.enemies.add(mmmmmmmmmore)
                    boss = Boss(settings.WORLD_WIDTH - 500, 200)
                    self.boss = boss
                    self.boss_group.add(self.boss)
                    self.finished = False

    def update_end(self):
        text = self.my_font.render("Please press "r" to replay", 1, (0, 0, 0))
        self.screen.blit(text, (0, 0))

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit(0)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit(0)
                if event.key == pygame.K_LEFT:
                    self.player.move_left()
                elif event.key == pygame.K_RIGHT:
                    self.player.move_right()
                if event.key == pygame.K_UP:
                    self.player.move_up()
                elif event.key == pygame.K_DOWN:
                    self.player.move_down()
                if event.key == pygame.K_SPACE:
                    new_bullet = YourBullet(self.player)
                    self.friendly_fire.add(new_bullet)

    def update(self):
        self.player_group.update(key.get_pressed())
        self.enemies.update()
        self.friendly_fire.update()
        self.aggravating_fire.update()
        self.camera.update(self.player)
        self.check_enemy_collision()
        self.check_boss_collision()
        self.check_boundary_collision()

    def draw(self):
        self.camera.update_rect(self.background)
        self.camera.update_rect(self.player_group)
        self.camera.update_rect(self.enemies)
        self.camera.update_rect(self.friendly_fire)
        self.camera.update_rect(self.aggravating_fire)
        self.background.draw(self.screen)
        score_text = self.my_font.render("Score = " + str(self.player.health), 1, (0, 0, 0))
        self.screen.blit(score_text, (50, settings.WINDOW_HEIGHT - 90))
        objective_text = self.my_font.render("Eat the \"fish\" and Kill the boss", 1, (0,0,0))
        self.screen.blit(objective_text, (300, settings.WINDOW_HEIGHT - 90))
        self.player_group.draw(self.screen)
        self.enemies.draw(self.screen)
        self.friendly_fire.draw(self.screen)
        self.aggravating_fire.draw(self.screen)


if __name__ == '__main__':
    Game().sequence()

from setuptools import setup

setup(
    name='GameProject',
    version='.01',
    packages=['data'],
    url='',
    license='',
    author='Zac Perkins',
    author_email='zgp99@yahoo.com',
    description='Fish Gamea'
)
